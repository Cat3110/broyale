##ReactJS and Socket.io Chat App Tutorial


This is the code from a tutorial done on youtube [here](https://www.youtube.com/playlist?list=PLfUtdEcvGHFHdOYFXj4cY6ZIFkSp6MOuY).

###Getting Started

First you'll need to fork or download the respository.

Then in terminal you'll install the node modules

``` npm install ```

Then you can run it using 

``` npm run react ``` to start React dev server.
``` npm run server ``` to start NodeJS Socket.io server.


